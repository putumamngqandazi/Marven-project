package Reporting;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

public class End_To_End_Reporting_And_Screenshots extends Reporting_Class {
        private WebDriver driver = Setup_Class.startBrowserOfChoice("https://shop.demoqa.com/shop", "chrome");

        OnlineShopping Login = PageFactory.initElements(driver,OnlineShopping.class);
        OnlineShopping Products = PageFactory.initElements(driver,OnlineShopping.class);
        OnlineShopping Cart = PageFactory.initElements(driver,OnlineShopping.class);
        OnlineShopping Checkout = PageFactory.initElements(driver,OnlineShopping.class);
        OnlineShopping Confirmation = PageFactory.initElements(driver,OnlineShopping.class);

        TakeScreenshot screenshot= new TakeScreenshot();
        @Test

        public void OnlineShopping() throws Exception{
            //Direct it to login
            test = extent.createTest("Login","Click login");
            test.log(Status.PASS," Take credentials");
            screenshot.takeSnapShot(driver, "Login page");

            //Direct it to Product
            test = extent.createTest("Product","Browse on the shopping site");
            test.log(Status.PASS,"Browse on Products");
            screenshot.takeSnapShot(driver, "Browse on Product");

            //Direct it to a cart
            test = extent.createTest("Cart","Click add to Cart");
            test.log(Status.PASS,"Go to view Cart");
            screenshot.takeSnapShot(driver, "Go to view cart");

            //Direct it to a Checkout
            test = extent.createTest("Checkout","Click Checkout");
            test.log(Status.PASS,"Browse on checkout");
            screenshot.takeSnapShot(driver, "Browse to checkout");

            //Confirmation
            test = extent.createTest("Confirmation","View confirmation");
            test.log(Status.PASS,"View confirmation");
            screenshot.takeSnapShot(driver, "View confirmation");


            Login.Login_Details();
            test.log(Status.PASS, "Verify if the entered details are valid");
            screenshot.takeSnapShot(driver, "Verify if the entered details are valid");

            Products.Navigate_Produts();
            test.log(Status.PASS, "If the entered details are valid view products");
            screenshot.takeSnapShot(driver, "Products page");

            Cart.Verify_Cart();
            test.log(Status.PASS, "Add Item to cart");
            screenshot.takeSnapShot(driver, "Navigate to view cart");

            Checkout.Navigate_toCheckout_Button();
            test.log(Status.PASS, "On cart click checkout,enter your checkout details");
            screenshot.takeSnapShot(driver, "Checkout");

            Confirmation.Display_Confirmation();
            test.log(Status.PASS, "View confirmation");
            screenshot.takeSnapShot(driver, "Confirmation");

        }
        @AfterSuite
        public void quit(){

            driver.quit();
        }
    }

